from boxfilter import boxfilter
import numpy as np

def WGIF(I, p, r, eps):
    # GUIDEDFILTER O(1) time implementation of guided filter.
    #
    # - guidance image: I(should be a gray - scale / single channel image)
    # - filtering input image: p(should be a gray - scale / single channel image)
    # - local window radius: r
    # - regularization parameter: eps
    hei = I.shape[0]
    wid = I.shape[1]

    #N = (2*r + 1)**2
    N = boxfilter(np.ones((hei, wid)), r) #the size of each local patch; N=(2r+1)^2 except for boundary pixels.

    mean_I = boxfilter(I, r)/N
    mean_p = boxfilter(p, r)/N
    mean_Ip = boxfilter(np.multiply(I, p), r)/N
    cov_Ip = mean_Ip - np.multiply(mean_I, mean_p) #this is the covariance of (I, p) in each local patch.

    mean_II = boxfilter(np.multiply(I, I), r)/N
    var_I = mean_II - np.multiply(mean_I, mean_I)

    #weight coefficient
    sigma = np.zeros((hei, wid))
    eps2 = (0.001*1*1)**2
    #eps2 = (1/255)**2

    N1 = boxfilter(np.ones((hei, wid)), 1)
    mean_I1 = boxfilter(I, 1)/N1
    mean_II1 = boxfilter(np.multiply(I, I), 1)/N1
    var_I1 = mean_II1 - np.multiply(mean_I1, mean_I1) #this is the covariance of I in each 1*1 patch
    sum_varI1 = ((1/(var_I1+eps2)).sum(axis=0)).sum(axis=0)
    sigma = (np.multiply(var_I1+eps2, sum_varI1))/(hei*wid)

    a = cov_Ip/ (var_I + (eps/ sigma)) #Eqn.(5) in the paper;
    b = mean_p - np.multiply(a, mean_I) #Eqn.(6) in the paper;

    mean_a = boxfilter(a, r) / N
    mean_b = boxfilter(b, r) / N

    q = np.multiply(mean_a, I) + mean_b  #Eqn.(8) in the paper;
    return q, sigma