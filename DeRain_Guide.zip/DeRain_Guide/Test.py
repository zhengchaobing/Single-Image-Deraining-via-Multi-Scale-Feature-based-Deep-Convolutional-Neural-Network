# python相关
import os
import warnings
# pytorh相关
import torch
from torch.utils import data
from skimage.measure.simple_metrics import compare_psnr
import numpy as np
# 自定义类
from config import get_arguments
import Dataset
import SavePicture
import skimage
#忽视警告
warnings.filterwarnings("ignore")

# 导入参数设置
parser = get_arguments()
opt = parser.parse_args()

torch.manual_seed(opt.seed)
if opt.cuda:
    torch.cuda.manual_seed(opt.seed)
#并行训练相关设置
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device=torch.device("cuda:0")

#读取数据集

test_dataset  = Dataset.DatasetTest(opt)
batch_test  = 1
test_loader  = data.DataLoader(dataset=test_dataset,  batch_size=batch_test,  shuffle=False,)


model_path = "checkpoint/{}/netG_model_epoch_{}.pth".format(opt.dataset, opt.nepochs)
model_restoration = torch.load(model_path).to(device)

model_restoration.eval()
with torch.no_grad():
        avg_psnr = 0.0; avg_ssim=0.0
        avg_psnr = 0.0
        for idx, (Rain, DeRain, detail) in enumerate(test_loader):
            print(idx)
            Fake_M = model_restoration(Rain, detail)[1]
            im = Fake_M[0, :, :, :].clone()
            im[0, :, :] = Fake_M[0, 2, :, :]
            im[2, :, :] = Fake_M[0, 0, :, :]
            SavePicture.save_from_tensor_test(im[:, :, :] * 255.0, './Data/DeRain/' + str(idx + 1) + '.png')

            img = Fake_M[0, :, :, :].clone()
            img = img.float().cpu().numpy()

            img0 = DeRain[0, :, :, :].clone()
            img0 = img0.float().cpu().numpy()

            img22 = np.transpose(img, (1, 2, 0))
            img00 = np.transpose(img0, (1, 2, 0))

            psnr = compare_psnr(img0, img, data_range=1.0)
            avg_psnr += psnr

            ssim = skimage.measure.compare_ssim(img00, img22, data_range=1.0, multichannel=True)
            avg_ssim += ssim

        print("===> Avg. PSNR: {:.6f} dB".format(avg_psnr / len(test_loader)))
        print("===> Avg. SSIM: {:.6f} dB".format(avg_ssim / len(test_loader)))