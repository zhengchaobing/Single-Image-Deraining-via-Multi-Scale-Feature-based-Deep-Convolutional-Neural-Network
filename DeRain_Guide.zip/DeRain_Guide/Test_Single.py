# python相关
import os
import warnings
# pytorh相关
import torch
from torch.utils import data
from skimage.measure.simple_metrics import compare_psnr
import numpy as np
# 自定义类
from config import get_arguments
import Dataset
import SavePicture
import skimage
import cv2
import numpy as np
import os
import random
import scipy.io as sio
import torchvision
from torchvision import transforms
from torch.autograd import Variable
#忽视警告
warnings.filterwarnings("ignore")

# 导入参数设置
parser = get_arguments()
opt = parser.parse_args()

torch.manual_seed(opt.seed)
if opt.cuda:
    torch.cuda.manual_seed(opt.seed)
#并行训练相关设置
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device=torch.device("cuda:0")

#读取数据集

test_dataset  = Dataset.DatasetTest(opt)
batch_test  = 1
test_loader  = data.DataLoader(dataset=test_dataset,  batch_size=batch_test,  shuffle=False,)


model_path = "checkpoint/{}/netG_model_epoch_{}.pth".format(opt.dataset, opt.nepochs)
model_restoration = torch.load(model_path).to(device)


def transformImage(image):
    image = torchvision.transforms.ToTensor()(image)
    Tensor = torch.cuda.FloatTensor
    image = Variable(image.type(Tensor))
    return image

model_restoration.eval()
with torch.no_grad():
        avg_psnr = 0.0; avg_ssim=0.0
        avg_psnr = 0.0

        mat = sio.loadmat('/netdisk-2.2-home/ZCB/A_Paper_DeRain/DeRain_Guide_Rain100_Heavy_DenoiseNet/Data/Mat_Heavy_Test/1.mat')
        img_Rain = mat["img_Rain"].astype(np.float64)
        img_noRain = (mat["img_noRain"]).astype(np.float64)
        haze_e = mat["haze_e"].astype(np.float64)

        Rain = transformImage(img_Rain).unsqueeze(0)
        detail = transformImage(haze_e).unsqueeze(0)
        Fake_M = model_restoration(Rain, detail)[1]

        im = Fake_M[0, :, :, :].clone()
        im[0, :, :] = Fake_M[0, 2, :, :]
        im[2, :, :] = Fake_M[0, 0, :, :]

        img = torch.clamp(im, 0, 255)
        # 反向标准化 到[0,1]区间
        img = (img).cpu().numpy().transpose((1, 2, 0))
        imgRain = img_Rain.copy()
        imgRain[:, :, 0] = img_Rain[:, :, 2]
        imgRain[:, :, 2] = img_Rain[:, :, 0]

        cv2.imshow("Rain", imgRain)
        cv2.imshow("DeRain",   img)
        cv2.waitKey()




