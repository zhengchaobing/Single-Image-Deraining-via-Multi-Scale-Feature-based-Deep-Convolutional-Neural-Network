function q = Improved_Weighted_Guided_Image_Filtering(I, p, r, eps, C)
    %   GUIDEDFILTER   O(1) time implementation of guided filter.
    %
    %   - guidance image: I (should be a gray-scale/single channel image)
    %   - filtering input image: p (should be a gray-scale/single channel image)
    %   - local window radius: r
    %   - regularization parameter: eps
    eta = 0.05;
    [hei, wid] = size(I);
    N = boxfilter(ones(hei, wid), r); % the size of each local patch; N=(2r+1)^2 except for boundary pixels.

    mean_I = boxfilter(I, r) ./ N;
    mean_p = boxfilter(p, r) ./ N;
    mean_Ip = boxfilter(I.*p, r) ./ N;
    cov_Ip = mean_Ip - mean_I .* mean_p; % this is the covariance of (I, p) in each local patch.

    clear mean_Ip;

    mean_II = boxfilter(I.*I, r) ./ N;
    var_I = mean_II - mean_I .* mean_I;

    clear mean_II;

    a = cov_Ip./(var_I+eps./C);
    b = mean_p-a.*mean_I;

    clear mean_I;

    mean_pp = boxfilter(p.*p, r) ./ N;
    var_p = mean_pp-mean_p.*mean_p;

    clear mean_p;
    clear mean_pp;

    e = a.^2.*var_p-2.*a.*cov_Ip+var_I;

    clear var_p;
    clear cov_Ip;
    clear var_I;

    gamma = exp(-e./eta);

    sum_a = boxfilter(a.*gamma, r);
    sum_gamma = boxfilter(gamma, r);
    clear a;
    sum_b = boxfilter(b.*gamma, r);
    clear b;
    clear gamma;
    q = (sum_a .* I + sum_b)./sum_gamma; % Eqn. (8) in the paper;

    clear sum_a;
    clear sum_b;
    clear sum_gamma;
end



