function [haze_b, haze_e] = decomposition_iWGIF(img_hazy)
%%%Decompose the haze image into two layers
    [height,width, color]= size(img_hazy);
    haze_Y = zeros(height, width);
    haze_b = zeros(height, width,3);
    haze_e = zeros(height, width,3);
    
    for i=1:height
        for j=1:width
            haze_Y(i,j) =floor((77*img_hazy(i,j,1)+150*img_hazy(i,j,2)+29*img_hazy(i,j,3)+128)/256);
        end
    end
    
    C = CalculateWeightingFactor_PixBased(haze_Y);

    h = fspecial('gaussian',  [16,16], 1); 
    C = imfilter( C,  h,  'same');
    r1 = 11;
    eps1 = 3; 
    for ii=1:3
        haze_b(:, :, ii)  = Improved_Weighted_Guided_Image_Filtering(haze_Y, img_hazy(:, :, ii), r1, eps1, C);  
        haze_e(:, :, ii) =  img_hazy(:, :, ii)- haze_b(:, :, ii);
    end
    clear haze_Y;    
    clear h;
    clear C;
end