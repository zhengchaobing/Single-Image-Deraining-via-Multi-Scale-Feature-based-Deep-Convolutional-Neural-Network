% This is a demo script demonstrating the non-local image dehazing algorithm
% described in the paper:
% Non-Local Image Dehazing. Berman, D. and Treibitz, T. and Avidan S., CVPR2016,
% which can be found at:
% www.eng.tau.ac.il/~berman/NonLocalDehazing/NonLocalDehazing_CVPR2016.pdf
% If you use this code, please cite our paper.
% 
% Please read the instructions on README.md in order to use this code.
%
% Author: Dana Berman, 2016. 
% 
% The software code of the Non-Local Image Dehazing algorithm is provided
% under the attached LICENSE.md


% Choose image to use, four example image are supplied with the code in the
% sub-folder "images":
for n= 1:21
        input_file=['G:\Single Image Dehazing\˼·�ļ�\Chaobing\', int2str(n) , '.jpg'];
        ouput_file=['C:\Users\Mobile_Robot\Desktop\dehazing\theta\4\', int2str(n) , '.png'];
        img_hazy = imread(input_file);

        IMPROVED = 1;
        TH = 1.0 / 4.0; %%%1.0/4.0 for normal haze and 1.0/8.0 for heavy haze
        gamma = 1.0;

        if IMPROVED==1
            [haze_b, haze_e] = decomposition_iWGIF(double(img_hazy));
        end

        % Estimate air-light using our method described in:
        % Air-light Estimation using Haze-Lines. Berman, D. and Treibitz, T. and 
        % Avidan S., ICCP 2017
        if IMPROVED ==1
            %     A = reshape(estimate_airlight(haze_b),1,1,3);
            % %Estimate the transmission map	
            %     trans_refined = non_local_dehazing(haze_b, A, gamma ); 

            %     A = reshape(estimate_airlight(im2double(img_hazy)),1,1,3);   
            %     %     A =reshape( Global_Airlight_Estimation(double(img_hazy)/255.0), 1,1,3);
            %     trans_refined = non_local_dehazing(img_hazy, A, gamma);    

            %     A = reshape(estimate_airlight(im2double(img_hazy)),1,1,3);   
            % %         A =reshape( Global_Airlight_Estimation(double(haze_b)/255.0), 1,1,3);
            %     trans_refined = non_local_dehazing(img_hazy, A, gamma);   

            %     A = reshape(estimate_airlight(im2double(uint8(haze_b))),1,1,3);   
            A = reshape(estimate_airlight(haze_b/255.0),1,1,3);   
            %         A =reshape( Global_Airlight_Estimation(double(haze_b)/255.0), 1,1,3);
            trans_refined = non_local_dehazing(  uint8(haze_b) ,  A, gamma);  

        else
            A = reshape(estimate_airlight(im2double(img_hazy)),1,1,3);
            %Estimate the transmission map	
            trans_refined = non_local_dehazing(img_hazy, A, gamma);
        end

        %%%Restored the haze-free image
        image_dehazed = restore_haze_free_image(im2double(img_hazy), A, trans_refined, im2double(haze_b), im2double(haze_e), TH, IMPROVED);
        imwrite(image_dehazed,  ouput_file );
     
end


