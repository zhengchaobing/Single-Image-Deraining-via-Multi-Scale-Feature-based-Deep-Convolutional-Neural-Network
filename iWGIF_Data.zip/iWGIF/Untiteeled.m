% Choose image to use, four example image are supplied with the code in the
% sub-folder "images":


    img= imread('I:\A_Paper_DeRain\Data_Set\Rain100Heavy\Test\Rain\111.png');
    figure; imshow(img);     title('input')
    [haze_b, haze_e] = decomposition_iWGIF(double(img)/255.0  );

    figure; imshow((haze_e));     title('haze_e'); imwrite(haze_e, '1.png');
   figure; imshow((haze_b));      title('haze_b');