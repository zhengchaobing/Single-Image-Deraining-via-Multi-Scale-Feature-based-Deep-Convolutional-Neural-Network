
for n= 1:12600
    n
    pa_Rain  =['I:\论文\论文\Derain论文\Data_Base\My_data\dataset3\train\False\', int2str(n) , '.png'];
    pa_noRain=['I:\论文\论文\Derain论文\Data_Base\My_data\dataset3\train\Truth\', int2str(n) , '.png'];
    
    ouput_Mat =['I:\论文\论文\Derain论文\Data_Base\My_data\dataset3\train\Mat\',  int2str(n) ,  '.mat'];
    
    img_Rain  = double( imread( pa_Rain) )   /255.0  ;
    img_noRain= double( imread( pa_noRain) ) /255.0  ;
    
    [haze_b, haze_e] = decomposition_iWGIF(img_Rain);
    
    
    save(ouput_Mat,'img_Rain', 'img_noRain', 'haze_e') ;
    
end