

for n= 1350:1450

    %The advantage of this version is shown by testing the image
    pa=['J:\A\Dehaze\Data\False\', int2str(n) , '.png'];
    warning('off','all');

    
    img_hazy = imread(pa);
    IMPROVED = 1;
    TH = 1.0/4.0; %%%1.0/4.0 for normal haze and 1.0/8.0 for heavy haze
    gamma = 1.2;

    if IMPROVED==1
        [haze_b, haze_e] = decomposition_iWGIF(double(img_hazy));
    end
    % Estimate air-light using our method described in:
    % Air-light Estimation using Haze-Lines. Berman, D. and Treibitz, T. and 
    % Avidan S., ICCP 2017
    if IMPROVED ==1
        %     A = reshape(estimate_airlight(haze_b),1,1,3);
        % %Estimate the transmission map	
        %     trans_refined = non_local_dehazing(haze_b, A, gamma ); 

        %     A = reshape(estimate_airlight(im2double(img_hazy)),1,1,3);   
        %     %     A =reshape( Global_Airlight_Estimation(double(img_hazy)/255.0), 1,1,3);
        %     trans_refined = non_local_dehazing(img_hazy, A, gamma);    

            A = reshape(estimate_airlight(im2double(uint8(haze_b))),1,1,3);   
        %         A =reshape( Global_Airlight_Estimation(double(haze_b)/255.0), 1,1,3);
            trans_refined = non_local_dehazing(  uint8(haze_b) ,  A, gamma);   

    else
        A = reshape(estimate_airlight(im2double(img_hazy)),1,1,3);
        %Estimate the transmission map	
        trans_refined = non_local_dehazing(img_hazy, A, gamma);
    end
    image_dehazed = restore_haze_free_image(im2double(img_hazy), A, trans_refined, im2double(haze_b), im2double(haze_e), TH, IMPROVED);

    ouput_file     =['J:\A\Dehaze\Data\Results\Me2\', int2str(n) , '.png'];
    imwrite(image_dehazed, ouput_file);
    warning('on','all');
    

end