function [img_dehazed] = restore_haze_free_image(img_hazy, air_light, transmission, haze_b, haze_e, TH, IMPROVED)

    [h,w,n_colors] = size(img_hazy);
    if IMPROVED==1
        %%%Decompistion of the hazy image   
        %% Dehazing
        % (Eq. (16))
         img_dehazed = zeros(h,w,n_colors);
         leave_haze = 17.0/16.0;
         trans_min = TH;

         %% (Eq. (38))
         %the2 = 1.0./( 1.0 + exp( 8.0*(1.0-1.625*transmission/(TH)) ) );
          % (Eq. (43))
          the2    = 1.0./( 1.0 + exp( 16.0*(1.0-transmission/TH) ) );

            theta2 = 1.0;
            for color_idx = 1:3
                img_dehazed(:,:,color_idx) =min( 255.0,  max( 0,  floor(     ( haze_b(:,:,color_idx) +theta2* the2(:,:).*haze_e(:,:,color_idx) - ...
                    air_light(color_idx)*255.0 )./ max(transmission,trans_min)+leave_haze*(air_light(color_idx)*255.0)...
                    +theta2 * 1.0* (  haze_e(:,:,color_idx) - the2(:,:).*haze_e(:,:,color_idx)  )   )))/255.0;

                % img_dehazed(:,:,color_idx)=min( 255.0,  max( 0,  floor(      (img_hazy(:,:,color_idx)  - air_light(color_idx)*255.0 ) ./ max(transmission,trans_min) + air_light(color_idx)*255.0 )))/255.0; %floor((AAA*(haze_I(i,j,k)-A_rgb(k))/(t(i,j)+1)+A_rgb(k))+0.5);            
            end
        else
                % (Eq. (16))
                img_dehazed = zeros(h,w,n_colors);
                leave_haze = 1.06; % leave a bit of haze for a natural look (set to 1 to reduce all haze)
                trans_min = 0.1;
                for color_idx = 1:3
                    img_dehazed(:,:,color_idx) = ( img_hazy(:,:,color_idx) - (1-leave_haze.*transmission).*(air_light(color_idx)) )./ max(transmission,trans_min); 
                end
    end

    % % Limit each pixel value to the range [0, 255] (avoid numerical problems)
    % img_dehazed=img_dehazed/255.0;
    img_dehazed(img_dehazed>1) = 1;
    img_dehazed(img_dehazed<0) = 0;
    % 
    % 
    % % For display, we perform a global linear contrast stretch on the output, 
    % % clipping 0.5% of the pixel values both in the shadows and in the highlights 
    % 
    adj_percent = [0.005, 0.995];
    img_dehazed = adjust(img_dehazed,adj_percent);
    img_dehazed = im2uint8(img_dehazed);

end % function non_local_dehazing
